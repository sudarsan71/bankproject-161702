package ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.mysql.jdbc.jdbc2.optional.SuspendableXAConnection;

import customer.Transactions;
import Exception.BankException;
import customer.Bean;
import service.BankService;

public class UserInterface {

	public static void main(String[] args) {
		
		//declaring variables for main 
		Scanner sc = new Scanner(System.in);
		Bean cus = new Bean();
		BankService s=new BankService();
		Bean bean=new Bean();
		boolean flag;
		int accno,ch;
		Random random=new Random();
		String name,ph,aadhar,addr;
		int age;
				
		System.out.println("welcome to the wallet");
		
		do
		{
		System.out.println("press 1 to create account" + "\npress 2 to show balance" + "\npress 3 to deposit"
				+ "\npress 4 to withdraw" + "\npress 5 to transfer" + "\npress 6 to print transactions");
		
		ch=sc.nextInt();
		switch (ch) 
		
		{
		
		case 1:
			//create account
		
			try
			{
			accno=random.nextInt(10000);
			bean.setAccno(accno);
			//getting name
			System.out.println("enter your name");
			
			do {
				name = sc.next();
				flag = s.isName(name);
				if(flag == false)
				{
					System.out.println("name format is Name");
				}
			} while (flag == false);
			bean.setName(name);
			
			//getting age
			System.out.println("enter your age");
			
			do {
				age = sc.nextInt();
				s.isAge(age);
				if(flag == false)
				{
					System.out.println("name format is Name");
				}
			} while (flag == false);
			bean.setAge(age);
			
			//getting phoneNo
			System.out.println("enter your phone number");
			
			do {
				ph = sc.next();
				s.isPh(ph);
				if(flag == false)
				{
					System.out.println("name format is Name");
				}
			} while (flag == false);
			bean.setPhoneno(ph);
			
			//getting address
			System.out.println("enter your address");
			
			do {
				addr = sc.next();
				s.isAddr(addr);
				if(flag == false)
				{
					System.out.println("name format is Name");
				}
			} while (flag == false);
			bean.setAddress(addr);
			
			//getting aadharno
			System.out.println("enter your aadhar number");
			
			do {
				aadhar = sc.next();
				s.isAadhar(aadhar);
				if(flag == false)
				{
					System.out.println("name format is Name");
				}
			} while (flag == false);
			bean.setAadharno(aadhar);
			
			//invoking create account and printing output
			s.createAccount(bean);
			
			
			System.out.println("accno is"+ bean.getAccno());
		}catch(BankException be)
		{
			System.out.println("the exception is" + be.getMessage());
		}
			
			break;
			
		
			
		case 2:
			//show balance
			try
			{
			System.out.println("enter account number");
			int eaccno;
			do{
				eaccno = sc.nextInt();
				flag=s.isAccno(eaccno);
				if(flag == false)
				{
					System.out.println("account number is invalid");
				}
			}while(flag == false);
			
			//invoking show balance and printing output
			
				System.out.println("your balance is" + s.showBalance(eaccno));
			
			}catch(BankException be)
			{
				System.out.println("the exception is" + be.getMessage());
			}
			break;
			
			
			
		case 3:
			//deposit
			try
			{
				System.out.println("enter the account no and amount to deposit");
			int eacc1;
			int edamnt;
			do{
				eacc1 = sc.nextInt();
				flag = s.isAccno(eacc1);
				if(flag == false)
				{
					System.out.println("account number is invalid");
				}
			}while(flag == false);
			
			do{
				edamnt = sc.nextInt();
				flag = s.isAmount(edamnt);
				if(flag == false)
				{
					System.out.println("enter valid amount");
				}
			}while(flag == false);
			
			//invoking deposit and printing output
			System.out.println("your new balance is"+s.deposit(eacc1,edamnt));
			
			}catch(BankException be)
			{
				System.out.println("the exception is" + be.getMessage());
			}
			break;
			
			
			
		case 4:
			//withdraw
			try
			{
				System.out.println("enter the account no and amount to withdraw");
			int eacc2;
			do{
				eacc2 = sc.nextInt();
				flag = s.isAccno(eacc2);
				if(flag == false)
				{
					System.out.println("account number is invalid");
				}
			}while(flag == false);
			int ewamnt;
			do{
				ewamnt = sc.nextInt();
				flag = s.isAmount(ewamnt);
				if(flag == false)
				{
					System.out.println("enter valid amount");
				}
			}while(flag == false);
			
			//invoking withdraw and printing output
			
			
			int t = s.withdraw(eacc2,ewamnt);
			
			if(t>=0)
			{
				System.out.println("your new balance is" +t);
			}
			else
			{
				System.out.println("insufficient balance...");
				System.out.println("your available balance is " + t);
			}
			}catch(BankException be)
			{
				System.out.println("the exception is" + be.getMessage());
			}
			break;
			
			
			
		case 5:
			//fund transfer
			try
			{
			System.out.println("enter the sender and receiver account number and amount to transfer");
			int sacc;
			do{
				sacc = sc.nextInt();
				flag=s.isAccno(sacc);
				if(flag== false)
				{
					System.out.println("account number is invalid");
				}
			}while(flag == false);
			int racc;
			do{
				racc = sc.nextInt();
				flag=s.isAccno(racc);
				if(flag == false)
				{
					System.out.println("account number is invalid");
				}
			}while(flag == false);
			int tamnt;
			do{
				tamnt = sc.nextInt();
				flag = s.isAmount(tamnt);
				if(flag == false)
				{
					System.out.println("enter valid amount");
				}
			}while(flag == false);
			if(s.transfer(sacc,racc,tamnt))
			{
				System.out.println("fund transfer is succesfull");
			}
			else
			{
				System.out.println("fund transfer failed... \n try once again");
			}
			}catch(BankException be)
			{
				System.out.println("the exception is" + be.getMessage());
			}
			
			break;
			
			
			
		case 6:
			//print transaction
			try
			{
				System.out.println("print transactions");
			System.out.println("enter the account number");
			int ptaccno;
			do{
				ptaccno = sc.nextInt();
				flag=s.isAccno(ptaccno);
				if(flag== false)
				{
					System.out.println("enter valid account number");
				}
			}while(flag == false);
			
			List<Transactions> pt=new ArrayList<Transactions>();
			pt = s.printTransactions(ptaccno);
			showList(pt);
			
			}
			catch(BankException be)
			{
				System.out.println("the exception is" + be.getMessage());
			}
			
			
			break;
			
		}	
		}while(ch<=6);
		
		
		}
	
	public static void showList(List<Transactions> pt)
	{
		for(Transactions temp:pt)
		{
			System.out.println(temp);
		}
		
	}

}

