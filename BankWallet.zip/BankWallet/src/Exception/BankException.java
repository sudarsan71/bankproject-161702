package Exception;

public class BankException extends Exception{
	public BankException()
	{
		super();
	
	}
	public BankException(String str)
	{
		super(str);
	}
	

}
