package utility;

import javax.persistence.EntityManager;

import javax.persistence.Persistence;

public class Utility {
	
	public static EntityManager getEntityManager()
	{
		return  Persistence.createEntityManagerFactory("BankWallet").createEntityManager();
	}

}
