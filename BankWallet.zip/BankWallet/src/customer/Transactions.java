package customer;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import customer.Bean;

@Entity
public class Transactions {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int transId;
	int amnt;
	String type;
	
	@ManyToOne
	@JoinColumn(name="accno")
	private Bean b;

	public int getAmnt() {
		return amnt;
	}

	public void setAmnt(int amnt) {
		this.amnt = amnt;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Bean getB() {
		return b;
	}

	public void setB(Bean b) {
		this.b = b;
	}

	@Override
	public String toString() {
		return "transId=" + transId + " amnt=" + amnt
				+ " type=" + type + "\n";
	}
	
	
	

}
