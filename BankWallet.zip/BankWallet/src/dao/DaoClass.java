package dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import utility.Utility;
import Exception.BankException;
import customer.Bean;
import customer.Transactions;

public class DaoClass implements DaoInterface{
	
	private EntityManager em = Utility.getEntityManager();
	//EntityManager em = null;
	
	
	@Override
	public int createAccount(Bean bean) throws BankException{
		// TODO Auto-generated method stub
		
		try
		{
			
		em = Utility.getEntityManager();
		em.getTransaction().begin();
		em.persist(bean);
		em.getTransaction().commit();
		return bean.getAccno();	
		}catch(PersistenceException e)
		{
			e.printStackTrace();
			throw new BankException(e.getMessage());
		}finally
		{
			em.close();
		}
	}

	@Override
	public int showBalance(int eaccno) throws BankException{
		
		try
		{
		em = Utility.getEntityManager();
		em.getTransaction().begin();
		Bean temp = em.find(Bean.class, eaccno);
		return temp.getBal();
		}catch(PersistenceException e)
		{
			e.printStackTrace();
			throw new BankException(e.getMessage());
		}finally
		{
			em.close();
		}
		
	}

	@Override
	public int deposit(int eacc1,int edamnt) throws BankException{
		// TODO Auto-generated method stub
		try
		{
		em=Utility.getEntityManager();
		em.getTransaction().begin();
		Bean temp = em.find(Bean.class, eacc1);
		int newBal = temp.getBal()+edamnt;
		temp.setBal(newBal);
		em.merge(temp);
		/*Transactions transaction = new Transactions();
		transaction.setB(temp);
		transaction.setAmnt(edamnt);
		em.persist(transaction);
		transaction.setType("deposit");
		em.persist(transaction);*/
		em.getTransaction().commit();
		return temp.getBal();
		}catch(PersistenceException e)
		{
			e.printStackTrace();
			throw new BankException(e.getMessage());
		}finally
		{
			em.close();
		}
		
	}
	
	
	@Override
	public int withdraw(int eacc2, int wamnt) throws BankException{
		
		try
		{
		em=Utility.getEntityManager();
		int newBal;
		em.getTransaction().begin();
		Bean temp = em.find(Bean.class, eacc2);
		int tempBal = temp.getBal();
		if(tempBal >= wamnt)
		{
		newBal = temp.getBal() - wamnt;
		temp.setBal(newBal);
		em.merge(temp);
		Transactions transaction = new Transactions();
		transaction.setB(temp);
		transaction.setAmnt(wamnt);
		em.persist(transaction);
		transaction.setType("withdraw");
		em.persist(transaction);
		em.getTransaction().commit();
		return temp.getBal();
		}
		
		
		return temp.getBal();	
		}catch(PersistenceException e)
		{
			e.printStackTrace();
			throw new BankException(e.getMessage());
		}finally
		{
			em.close();
		}
		
		


	}

	@Override
	public boolean transfer(int sacc,int racc,int tamnt) throws BankException{
		
		try
		{
		em=Utility.getEntityManager();
		int newBal;
		em.getTransaction().begin();
		Bean temp1 = em.find(Bean.class, sacc);
		int tempBal = temp1.getBal();
		if(tempBal >= tamnt)
		{
		newBal = temp1.getBal() - tamnt;
		temp1.setBal(newBal);
		Bean temp2 = em.find(Bean.class, racc);
		newBal = temp2.getBal()+tamnt;
		temp2.setBal(newBal);
		em.merge(temp1);
		em.merge(temp2);
		Transactions transaction1 = new Transactions();
		transaction1.setB(temp1);
		transaction1.setAmnt(tamnt);
		transaction1.setType("withdraw");
		em.persist(transaction1);
		Transactions transaction2 = new Transactions();
		transaction2.setB(temp2);
		transaction2.setAmnt(tamnt);
		transaction2.setType("deposit");
		em.persist(transaction2);
		em.getTransaction().commit();
		return true;
		}
		}catch(PersistenceException e)
		{
			e.printStackTrace();
			throw new BankException(e.getMessage());
		}finally
		{
			em.close();
		}
		return false;
	}
	
	public List<Transactions> printTransactions(int ptaccno) throws BankException
	{
		
		em=Utility.getEntityManager();
		em.getTransaction().begin();
		List<Transactions> pt = new ArrayList<Transactions>();
		Query query = em.createNativeQuery("select * from transactions where accno = ?",Transactions.class);
		query.setParameter(1, ptaccno);
		pt = query.getResultList();
		
			
		return pt;
		
	}
			
		

	
	
	
	
	
	
	
	
}
