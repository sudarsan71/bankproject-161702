package dao;

import static org.junit.Assert.*;


import org.junit.Test;
import Exception.BankException;
import customer.Bean;


public class DaoClassTest {
	DaoClass dc = new DaoClass();
	Bean b = null;
	
	@Test
	public void testCreateAccount() {
		
		b=new Bean();
		b.setAadharno("292929292929");
		b.setAccno(1935);
		b.setPhoneno("9043711096");
		b.setAddress("parthasarathy street");
		b.setBal(0);
		b.setAge(21);
		b.setName("sud");
		int accno;
		try {
			accno = dc.createAccount(b);
			assertEquals(1935,accno);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			System.out.println("create account failed");
		}
		
	
}

	@Test
	public void testShowBalance() {
		
		int bal1=0;
		try {
			bal1 = dc.showBalance(1935);
			
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("show balance failed");
		}
		assertEquals(0, bal1);
		
		
		
	}

	@Test
	public void testDeposit() {
		int newbal = 0;
		try {
				newbal = dc.deposit(1935, 2000);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("deposit failed");
		}
		assertEquals(2000, newbal);

	}

	@Test
	public void testWithdraw() {
		int newbal = 0;
		try {
				newbal = dc.withdraw(1935, 200);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("withdraw failed");
		}
		assertEquals(1800, newbal);

	}

	@Test
	public void testTransfer() {
		boolean bool = true;
		try {
				bool = dc.transfer(1935, 4287	, 200);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("fund transfer failed");
		}
		assertEquals(true, bool);	}

	/*@Test
	public void testPrintTransactions() {
		fail("Not yet implemented");
	}*/

}
